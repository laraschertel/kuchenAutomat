package automat;

import java.io.Serializable;

public enum Allergen implements Serializable {
    Gluten,Erdnuss,Haselnuss,Sesamsamen
}
