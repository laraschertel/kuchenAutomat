package automat;

import java.io.Serializable;

public interface Hersteller {
    String getName();
}
