package automat;


    public class AutomatException extends Exception {
        public AutomatException() {super (); }
        public AutomatException(String message) {super (message); }


    }

