package automat;

public interface Obstkuchen extends Kuchen,Verkaufsobjekt {
    String getObstsorte();
}
