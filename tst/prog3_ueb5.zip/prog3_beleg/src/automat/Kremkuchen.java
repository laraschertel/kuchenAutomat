package automat;

public interface Kremkuchen extends Kuchen,Verkaufsobjekt {
    String getKremsorte();
}
